package com.sky.library.service;

import com.sky.library.book.Book;
import com.sky.library.book.BookSummary;
import com.sky.library.exception.BookNotFoundException;
import com.sky.library.exception.InvalidBookReferenceException;
import com.sky.library.repository.BookRepositoryStub;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;
import org.junit.jupiter.params.provider.ArgumentsSource;

import java.util.stream.Stream;

import static com.sky.library.repository.BookRepositoryStub.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class BookServiceTest {
    private static final String INVALID_TEXT = "INVALID_TEXT";
    private static final String UNKNOWN_BOOK_REFERENCE = "BOOK-999";
    BookRepositoryStub bookRepositoryStub;
    BookService bookService;

    @BeforeAll
    public void setup() {
        bookRepositoryStub = new BookRepositoryStub();
        bookService = new YoungAdultBookService(bookRepositoryStub);
    }

    @Test
    public void retrieveBook_invalidReference_shouldThrowInvalidBookReferenceException() {
        try {
            bookService.retrieveBook(INVALID_TEXT);
            fail("Expected exception to be thrown");
        } catch (InvalidBookReferenceException | BookNotFoundException e) {
            assertThat(e instanceof InvalidBookReferenceException);
            assertThat(e.getMessage()).contains("Book reference INVALID_TEXT - must begin with \"BOOK-\"");
        }
    }

    @Test
    public void retrieveBook_BookNotFound_shouldBookNotFoundException() {
        assertThrows(BookNotFoundException.class, () ->
                bookService.retrieveBook(UNKNOWN_BOOK_REFERENCE));
    }

    @ParameterizedTest(name = "{index} => bookReference={0}, expectedBook={1}")
    @ArgumentsSource(RetrieveBookArgumentsProvider.class)
    public void shouldRetrieveBook(String bookReference,
                                   Book expectedBook) throws BookNotFoundException {
        assertThat(bookService.retrieveBook(bookReference)).isEqualTo(expectedBook);
    }

    @ParameterizedTest(name = "{index} => bookReference={0}, expectedBookSummary={1}")
    @ArgumentsSource(BookSummaryArgumentsProvider.class)
    public void shouldGetBookSummary(String bookReference,
                                     String expectedSummary) throws BookNotFoundException {
        assertThat(bookService.getBookSummary(bookReference)).isEqualTo(expectedSummary);
    }

    @Test
    public void getBookSummary_invalidReference_shouldThrowInvalidBookReferenceException() {
        try {
            bookService.getBookSummary(INVALID_TEXT);
            fail("Expected exception to be thrown");
        } catch (InvalidBookReferenceException | BookNotFoundException e) {
            assertThat(e instanceof InvalidBookReferenceException);
            assertThat(e.getMessage()).contains("Book reference INVALID_TEXT - must begin with \"BOOK-\"");
        }
    }

    @Test
    public void getBookSummary_bookNotFound_shouldThrowBookNotFoundException() {
        assertThrows(BookNotFoundException.class, () ->
                bookService.getBookSummary(UNKNOWN_BOOK_REFERENCE));
    }

    static class RetrieveBookArgumentsProvider implements ArgumentsProvider {
        @Override
        public Stream<? extends Arguments> provideArguments(ExtensionContext context) {
            return Stream.of(
                    Arguments.of(
                            THE_GRUFFALO_REFERENCE,
                            Book.builder()
                                    .title(THE_GRUFFALO_TITLE)
                                    .reference(THE_GRUFFALO_REFERENCE)
                                    .review(THE_GRUFFALO_DESCRIPTION)
                                    .build()),
                    Arguments.of(
                            THE_WIND_IN_THE_WILLOWS_REFERENCE,
                            Book.builder()
                                    .title(THE_WIND_IN_THE_WILLOWS_TITLE)
                                    .reference(THE_WIND_IN_THE_WILLOWS_REFERENCE)
                                    .review(THE_WIND_IN_WILLOWS_DESCRIPTION)
                                    .build()),
                    Arguments.of(
                            WINNIE_THE_POOH_REFERENCE,
                            Book.builder()
                                    .title(WINNIE_THE_POOH_TITLE)
                                    .reference(WINNIE_THE_POOH_REFERENCE)
                                    .review(WINNIE_THE_POOH_DESCRIPTION)
                                    .build())
            );
        }
    }

    static class BookSummaryArgumentsProvider implements ArgumentsProvider {
        @Override
        public Stream<? extends Arguments> provideArguments(ExtensionContext context) {
            return Stream.of(
                    Arguments.of(
                            THE_GRUFFALO_REFERENCE,
                            bookSummary(Book.builder()
                                    .title(THE_GRUFFALO_TITLE)
                                    .reference(THE_GRUFFALO_REFERENCE)
                                    .review(THE_GRUFFALO_DESCRIPTION)
                                    .build())),
                    Arguments.of(
                            WINNIE_THE_POOH_REFERENCE,
                            bookSummary(Book.builder()
                                    .title(WINNIE_THE_POOH_TITLE)
                                    .reference(WINNIE_THE_POOH_REFERENCE)
                                    .review(WINNIE_THE_POOH_DESCRIPTION)
                                    .build())),
                    Arguments.of(
                            THE_WIND_IN_THE_WILLOWS_REFERENCE,
                            bookSummary(Book.builder()
                                    .title(THE_WIND_IN_THE_WILLOWS_TITLE)
                                    .reference(THE_WIND_IN_THE_WILLOWS_REFERENCE)
                                    .review(THE_WIND_IN_WILLOWS_DESCRIPTION)
                                    .build())));
        }
    }

    static class InvalidBookReferenceProvider implements ArgumentsProvider {
        @Override
        public Stream<? extends Arguments> provideArguments(ExtensionContext context) throws ClassNotFoundException, NoSuchMethodException {
            return Stream.of(
                    Arguments.of(
                            Class.forName("BookService").getMethod("retrieveBook", String.class)
                    ),
                    Arguments.of(
                            Class.forName("BookService").getMethod("getBookSummary", String.class)
                    ));

        }
    }

    private static String bookSummary(Book book) {
        return BookSummary.create(book).getBookSummary();
    }

}

