### Unattended Programming Exercise
### Built using:
   Java 13
   Gradle
Note no JavaDocs, as per spec.
   Added dependencies: lombok, assertJ, junit-5(jupiter)
   
### To run, please issue at project root:
   ./gradlew clean build
   
### Please see tests - BookServiceTest, BookSummaryUtilsTest

