package com.sky.library.book;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

public class BookSummaryUtilsTest {
    @ParameterizedTest
    @CsvSource({
            "The quick brown fox, The quick brown fox",
            "'The lion the witch, and the wardrobe et al.','The lion the witch, and the wardrobe et al.'",
            "'Snoopy Doo where are you? and other like stories', 'Snoopy Doo where are you? and other like stories'",
            "'Harry Potter and the Prince of thieves is the thirteenth book in the series', 'Harry Potter and the Prince of thieves is the...'",
            "'Harry Potter and the Prince of thieves is the? thirteenth book in the series', 'Harry Potter and the Prince of thieves is the...'",
            "'Harry Potter and the Prince of thieves is the^ thirteenth book in the series', 'Harry Potter and the Prince of thieves is the...'"
    })
    public void shouldTruncateText(String inputText, String expectedOutputText) {
        assertThat(BookSummaryUtils.truncateText(inputText)).isEqualTo(expectedOutputText);
    }
}
