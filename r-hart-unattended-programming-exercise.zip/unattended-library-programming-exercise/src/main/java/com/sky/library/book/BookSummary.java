package com.sky.library.book;

import java.util.Objects;
import java.util.StringJoiner;

import static com.sky.library.book.BookSummaryUtils.*;

public final class BookSummary {
    private final Book book;
    private String bookSummary;

    private BookSummary(Book book) {
        this.book = Objects.requireNonNull(book);
        this.bookSummary = bookSummary();
    }

    public static BookSummary create(Book book) {
        return new BookSummary(book);
    }

    public String getBookSummary() {
        return bookSummary;
    }

    private String bookSummary() {
        StringJoiner sj = new StringJoiner(WHITESPACE);
        summaryReferenceAndTitle(sj);
        String summary = truncateText(book.getReview());
        return sj.add(summary).toString();
    }

    private void summaryReferenceAndTitle(StringJoiner sj) {
        sj.add(SQUARE_BRACKET_START.concat(book.getReference()).concat(SQUARE_BRACKET_END))
                .add(book.getTitle())
                .add(HYPHEN);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BookSummary summary = (BookSummary) o;

        if (!Objects.equals(book, summary.book)) return false;
        return Objects.equals(bookSummary, summary.bookSummary);
    }

    @Override
    public int hashCode() {
        int result = book != null ? book.hashCode() : 0;
        result = 31 * result + (bookSummary != null ? bookSummary.hashCode() : 0);
        return result;
    }
}
