package com.sky.library.service;

import com.sky.library.book.Book;
import com.sky.library.book.BookSummary;
import com.sky.library.exception.BookNotFoundException;
import com.sky.library.exception.InvalidBookReferenceException;
import com.sky.library.repository.BookRepository;

import java.util.Objects;

import static com.sky.library.book.BookSummaryUtils.*;

public class YoungAdultBookService implements BookService {
    private BookRepository bookRepository;

    public YoungAdultBookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    public Book retrieveBook(String bookReference) throws BookNotFoundException {
        if (!validBookPrefix(bookReference)) {
            throw new InvalidBookReferenceException(String.format("Book reference %s - must begin with \"BOOK-\"", bookReference));
        }
        Book book = bookRepository.retrieveBook(bookReference);
        if (book == null) {
            throw new BookNotFoundException(String.format("Unable to find book reference %s",bookReference));
        }
        return book;
    }

    @Override
    public String getBookSummary(String bookReference) throws BookNotFoundException {
        Book foundBook = retrieveBook(bookReference);
        return BookSummary.create(foundBook).getBookSummary();
    }

    private boolean validBookPrefix(String bookReference) {
        Objects.requireNonNull(bookReference);
        return beginsWith(bookReference);
    }
}
