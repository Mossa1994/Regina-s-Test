package com.sky.library.book;

import java.util.Arrays;
import java.util.regex.Pattern;

public class BookSummaryUtils {
    static final int EXCEEDED_WORDS_IN_SUMMARY = 9;
    static final String HYPHEN = "-";
    static final String WHITESPACE = " ";
    static final String SQUARE_BRACKET_START = "[";
    static final String SQUARE_BRACKET_END = "]";
    private static final String PUNCTUATION_REGEX = ".*\\p{Punct}$";
    private static final String NON_STRING_REGEX = "\\s";
    private static final String BOOK_REFERENCE_PREFIX = "BOOK-";
    private static final String ELLIPSIS = "...";
    private static final String WHITESPACE_REGEX = "\\s+";

    public static boolean beginsWith(String text) {
        return text.startsWith(BOOK_REFERENCE_PREFIX);
    }

    /**
     * @param text Requirements:Exceeds 9 words
     * @return truncated text (9 words, + ...).
     * Eg  "apple book carrot dog echo foxtrot geranium happy indigo, jekyll" becomes
     * "apple book carrot dog echo foxtrot geranium happy indigo..."
     */
    public static String truncateText(String text) {
        if (shortenReviewDesc(text)) {
            String[] truncatedText = truncateAfterWords(EXCEEDED_WORDS_IN_SUMMARY, text);
            deleteTrailingPunctAppendEllipsis(truncatedText);
            return String.join(WHITESPACE, truncatedText);
        }
        return text;
    }

    private static boolean shortenReviewDesc(String text) {
        return EXCEEDED_WORDS_IN_SUMMARY < wordCount(text);
    }

    private static String[] truncateAfterWords(int n, String text) {
        String[] src = text.split(NON_STRING_REGEX, n + 1);
        int destLen = src.length;
        if (n < src.length) {
            src[n] = null;
            destLen = n;
        }
        String[] dest = new String[destLen];
        System.arraycopy(src, 0, dest, 0, dest.length);
        return dest;
    }

    private static void deleteTrailingPunctAppendEllipsis(String[] text) {
        if (endsWithPunctuation(text[text.length - 1])) {
            text[text.length - 1] = text[text.length - 1].substring(0, text[text.length - 1].length() - 1);
        }
        text[text.length - 1] = text[text.length - 1].concat(ELLIPSIS);
    }

    private static boolean endsWithPunctuation(String input) {
        return Pattern.matches(PUNCTUATION_REGEX, input);
    }

    private static long wordCount(String text) {
        return Arrays.stream(text.split(WHITESPACE_REGEX)).count();
    }
}
